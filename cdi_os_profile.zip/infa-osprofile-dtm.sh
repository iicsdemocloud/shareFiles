#!/bin/sh
input_args="$@"
env_var_file=$(mktemp)
chmod +r "${env_var_file}"
export -p > "${env_var_file}"
[ -e "/etc/configs/osp_config_${ENV_INFA_DTM_OSPROFILE_USER}.sh" ] && cat /etc/configs/osp_config_${ENV_INFA_DTM_OSPROFILE_USER}.sh >> "${env_var_file}"
sudo -u ${ENV_INFA_DTM_OSPROFILE_USER} -- bash -c ". ${env_var_file}; cd ${PWD}; ${input_args}"
exit_code=$?
rm -f "${env_var_file}"
exit "${exit_code}"
