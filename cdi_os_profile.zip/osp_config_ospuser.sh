export SOME_VAR=123 
