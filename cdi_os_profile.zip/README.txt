Configure OS Profiles for CDI

Files:
- osp_users.txt - Example file containing the list of OS Profiles users that will be used
- osp_config_ospuser.sh - Example file list of environment variables for the OS Profile user called "ospuser".  One of these files would be created per OS Profile user.
- infa-osprofile-dtm.sh Script executed by the secure agent user to start CDI jobs as the OS Profile user.  See https://docs.informatica.com/cloud-common-services/administrator/current-version/secure-agent-services/data-integration-server/data-integration-server-properties.html OSProfileScriptForTaskExecution and https://docs.informatica.com/cloud-common-services/administrator/current-version/secure-agent-services/data-integration-server/data-integration-server-properties/setting_the_osprofilescriptfortaskexecution.html.  This version of the script has some advantages over the example script in the documentation:
		1. Instead of unlimited sudo access, the Secure Agent user only needs sudo access to run as the OS Profile users
		2. Provides a mechanism to provide OS Profile user specific environment variables to each OS Profile
- setup_osp_users.sh - Creates the OS Profile users, gives the secure agent user sudo access to run as each of the OS Profile users and copies infa-osprofile-dtm.sh under the secure agent installation.
- OSProfileUserMappingFile.yaml - See https://docs.informatica.com/cloud-common-services/administrator/current-version/secure-agent-services/data-integration-server/data-integration-server-properties.html OSProfileUserMappingFile property and https://docs.informatica.com/cloud-common-services/administrator/current-version/secure-agent-services/data-integration-server/data-integration-server-properties/creating_the_osprofileusermappingfile.html.