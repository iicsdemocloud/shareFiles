#!/bin/bash

# Configure OS Profiles
#
unset osp_user_list
while read ospuser; do
    echo $(date -u) ": Creating OS Profile user $ospuser"
    useradd $ospuser
    if [ -z "$osp_user_list" ]; then
        osp_user_list="$ospuser"
    else
        osp_user_list="$osp_user_list,$ospuser"
    fi
done </etc/configs/osp_users.txt

echo $(date -u) ": Adding sudo privileges to OS profile users for agentuser"
echo "agentuser ALL=($osp_user_list) NOPASSWD: ALL" | EDITOR='tee -a' visudo

cp /etc/configs/infa-osprofile-dtm.sh $SECURE_AGENT_BASE/apps/Data_Integration_Server/ext/
chmod 755 $SECURE_AGENT_BASE/apps/Data_Integration_Server/ext/infa-osprofile-dtm.sh